from PySide2.QtCore import QThread

class pictureThread(QThread):

    def __init__(self):
        super().__init__()

    def run(self):
        pass