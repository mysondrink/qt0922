this is a new reagent-test program
refactering my old reagent-test program

this is a refactering reagent-test program, starting at 2023-09-22.
it's recontructed by my old reagent-test project.
and i records the process of this project